/*
 * File:   main.cpp
 * Author: Adam Grambergs
 * Created on January 8, 2018, 12:40 AM
 * Purpose: Write a program that stores the following values in five different variables: 28, 32, 37, 24, and 33. The program should first calculate the sum of these five variables and store the result in a separate variable names sum. Then, the program, should divide the sum variable by 5 to get the average. 
 */
//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main() 
{
    //Declare Variables
    float a(28), b(32), c(37), d(24), e(33), sum(a+b+c+d+e), average(sum/5);
      
        
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    cout << "Average is: " << average << endl;
   
    //Exit stage right!
    return 0;
}