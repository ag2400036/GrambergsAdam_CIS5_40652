/* 
 * File:   main.cpp
 * Author: Adam Grambergs
 * Created on January 8, 2018, 12:40 AM
 * Purpose: Write a program that stores integers 50 and 100 in variables, and stores the sum of these two in a variable names total. 
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main() 
{
    //Declare Variables
    int a = 50;
    int b = 100;
    int total = a + b; 
    
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    
    cout << "The sum is: " << total << endl;
    //Exit stage right!
    return 0;
}