/*
 * File:   main.cpp
 * Author: Adam Grambergs
 * Created on January 8, 2018, 4:23 PM
 * Purpose:  Write a program that displays the following pattern on the screen: 
 *      *
 *     ***
 *    *****
 *   *******
 */
//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main() 
{
    //Declare Variables
      
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    cout << "      *\n";
    cout << "     ***\n";
    cout << "    *****\n";
    cout << "   *******\n";    
   
    //Exit stage right!
    return 0;
}